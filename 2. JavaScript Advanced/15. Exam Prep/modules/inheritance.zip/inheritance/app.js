let Entity = require('./entity');
let Dog = require('./dog');
let Person = require('./person');
let Student = require('./student');

// let dog = new Dog('Sparky');
// console.log(dog.saySomething());
//
// let person = new Person('Dexter', 'Hello my dog!', dog);
// console.log(person.saySomething());
//
// let student = new Student('Peter', 'Sup doggy?', dog, 22);
// console.log(student.saySomething());

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;